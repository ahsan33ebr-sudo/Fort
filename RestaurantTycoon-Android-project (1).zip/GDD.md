# Restaurant Tycoon Factory — Game Design Document

## Product vision
A portrait-independent, landscape-first mobile factory/restaurant management game. Players lay out ingredient supply and kitchen production lines on a broad tile map, then convert throughput, service capacity and power into restaurant reputation. The visual language is warm, readable flat art with playful ingredient glyphs and a deep green/gold palette.

## Core loop
Survey nearby ingredient patches → place farms/coops/gardens/pumps → connect ingredient machines with belts → refine wheat to flour to dough → route cooking output to dining → expand power and guest capacity → earn cash, stars and unlocks. Building costs are paid at placement; dismantling refunds 60%. Guest service and passive daily events provide early earnings so the player can develop the factory.

## Map and interaction
A 60×44 procedural grassland has wheat, water and vegetable zones. Phaser 3 renders visible tile neighborhoods with world camera pan, wheel/pinch zoom support, mini-map camera navigation and mobile pointer input. Tap places the active building, drag pans, belt drag draws a run, rotate cycles machine orientation, undo removes the most recent structure, erase refunds, and copy/paste repeats a type. Touch-target controls are at least 48 CSS px. UI avoids browser zoom and overscroll and honors safe-area insets.

## Building catalogue
Raw: Wheat farm ($90), chicken coop ($120), vegetable garden ($100), water pump ($110). Logistics: conveyor ($8/tile), pantry ($85). Processing: flour mill ($150), dough maker ($180). Cooking: pizza oven ($230). Power: solar ($130, 2 units), biogas ($180, 5 units), battery ($95). Restaurant: customer table ($140), service counter ($120), billboard ($170). Buildings have distinct color/icon, cost, stock display and placement validation.

## Production and economy
Ingredient sources produce inventory on a cadence. Mill consumes adjacent wheat for flour, dough maker consumes adjacent flour, and oven consumes adjacent dough. Tables consume finished goods routed to them and generate revenue, customers served, and incremental rating. Conveyors can be drawn in a continuous gesture. Income, reputation and guest demand persist between sessions. Solar/biogas output and machine demand are surfaced in the compact HUD. The simulation pauses in pause menu/background and saves to local storage every 30 seconds and on lifecycle hide.

## Competition/events/progression
Restaurant rating ranges from one to five stars, with a rival rating and periodic lunch rush, critic, supplier and competitor events. Day count advances with service. Revenue and stars form the player growth/competition loop. The menu is designed for additional campaign recipe/building unlocks; the current build starts with the wheat-to-pizza vertical slice.

## Multiplayer
Optional Node.js `ws` server supports 6-character rooms, 2–8 connected players, host-authoritative state broadcasts, host migration, join/host, player lists, chat and action forwarding. It is separated from offline single-player and can be run on a LAN or deployed behind a TLS reverse proxy. Server address/connection UI is not yet integrated into the game client.

## Art, accessibility, audio
All game visuals are procedural Phaser vector shapes and native emoji glyphs; no remote art/fonts/audio are required. UI uses high contrast and large controls. Haptic vibration is invoked on building placement/removal where supported. Sound/music are omitted in this build.

## Saves and target
Web build is an installable landscape PWA and single-player is offline-capable once cached. Capacitor Android uses ID `com.restauranttycoon.game`; intended Android min SDK 24. CI workflow builds a debug APK on GitHub Actions.

## Current scope and known limitations
This is a complete playable vertical slice, not the entire requested Mindustry-scale feature list. Current simulation has a focused pizza production line; power is represented in the HUD but does not gate machine operation, belts are visual/layout tools rather than item-by-item transport, and tables serve when stocked. No functional tech tree, campaign, rival AI behavior, QR room flow, in-client multiplayer/chat UI, audio, real-time lighting, generated unique sprite atlas, signed release build, or server-side anticheat. Platform plugin integrations are minimal. These require substantially more development and testing than the available environment permits. Offline play, building, saving, service, rating, events, mini-map, mobile input and multiplayer room server are implemented.
